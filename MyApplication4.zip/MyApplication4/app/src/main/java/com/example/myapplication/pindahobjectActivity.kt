package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class pindahobjectActivity : AppCompatActivity() {

    private lateinit var tvPenerimaObjek : TextView

    companion object {

        const val EXTRA_motorcycle = "extra_motorcycle"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pindahobject)

        tvPenerimaObjek =findViewById(R.id.tv_penerima_object)

        val cars : motorcycle = intent.getStringExtra(EXTRA_motorcycle) as motorcycle
        val text = "merk : ${motorcycle.merk.toString()} \nTahun :${motorcycle.tahun.toString()} \nPlat : ${motorcycle.plat.toString()}"
        tvPenerimaObjek.text = text
    }
}